#include "helpers.h"

const char* user_register_login(char *host, int port, char *payload_type, char *access_route);
