Repository for the first homework of the Communication Networks class. In this homework the students will implement the dataplane of a router.
